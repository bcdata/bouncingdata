#R code
library("RCurl")

bcAnalysisPublish <- function(filename,title="Analysis Title",description="Analysis description",base_uri="http://bouncingdata.com") {

contentType <- "text/plain"
file <- fileUpload(filename = filename, contentType = contentType)

uri <- paste(base_uri, "/public/ide/publish", sep="");
curl <- getCurlHandle()
style <- 'HTTPPOST'
.encoding <- 'UTF-8'
binary <- NA
.checkParams <- TRUE

#TODO password as parameters / user input
user <- readline("Input user name:")
params = list(file1=file,user=user,title=title,description=description)

ret <- postForm(uri = uri, .params = params, curl = curl, style = style, .encoding = .encoding, binary = binary, .checkParams = .checkParams)

if(ret == "Upload failed" || ret == "Execution failed") 
{
 print(ret)		
} else {
 print(paste("Analysis publishing succeeded. Your analysis url is ", base_uri, "/anls/", ret, sep=""))
}

return (ret)
}

bcDatasetPublish <- function(filename,title="Dataset Title",description="Dataset description",tags="",base_uri="http://bouncingdata.com") {

contentType <- "text/plain"
file <- fileUpload(filename = filename, contentType = contentType)

uri <- paste(base_uri, "/public/ide/publish_dataset", sep="");
curl <- getCurlHandle()
style <- 'HTTPPOST'
.encoding <- 'UTF-8'
binary <- NA
.checkParams <- TRUE

#TODO password as parameters / user input
user <- readline("Input user name:")
params = list(file1=file,user=user,title=title,description=description,tags=tags)

ret <- postForm(uri = uri, .params = params, curl = curl, style = style, .encoding = .encoding, binary = binary, .checkParams = .checkParams)

if(ret == "Upload failed" || ret == "Execution failed") 
{
 print(ret)		
} else {
 print(paste("Dataset publishing succeeded. Your dataset url is ", base_uri, "/dataset/view/", ret, sep=""))
}

return (ret)
}
