#R code
library("RCurl")
library("rjson")

bcAnalysisPublish <- function(filename,title="Analysis Title",description="Analysis description",public="false", base_uri="http://bouncingdata.com") {

contentType <- "text/plain"
file <- fileUpload(filename = filename, contentType = contentType)

uri <- paste(base_uri, "/public/ide/publish", sep="");
curl <- getCurlHandle()
style <- 'HTTPPOST'
.encoding <- 'UTF-8'
binary <- NA
.checkParams <- TRUE

user <- readline("Input user name:")
password <-readline("Input password:")
.opts <- curlOptions(url = uri, password = password)

params = list(file1=file,user=user,password=password,title=title,description=description,isPublic=public)

retJSON <- postForm(uri = uri, .params = params, .opts = .opts, curl = curl, style = style, .encoding = .encoding, binary = binary, .checkParams = .checkParams)

ret <- fromJSON(retJSON)

if(ret["code"] != 0) 
{
 print(ret["message"])		
} else {
 print(paste("Analysis publishing succeeded. Your analysis url is ", base_uri, "/anls/", ret["message"], sep=""))
}

return (ret)
}

bcDatasetPublish <- function(filename,title="Dataset Title",description="Dataset description",tags="",public="false",base_uri="http://bouncingdata.com") {

contentType <- "text/plain"
file <- fileUpload(filename = filename, contentType = contentType)

uri <- paste(base_uri, "/public/ide/publish_dataset", sep="");
curl <- getCurlHandle()
style <- 'HTTPPOST'
.encoding <- 'UTF-8'
binary <- NA
.checkParams <- TRUE

user <- readline("Input user name:")
password <- readline("Input password:")
.opts <- curlOptions(url = uri, password = password)

params = list(file1=file,user=user,password=password,title=title,description=description,tags=tags,isPublic=public)

retJSON <- postForm(uri = uri, .params = params, .opts = .opts, curl = curl, style = style, .encoding = .encoding, binary = binary, .checkParams = .checkParams)

ret <- fromJSON(retJSON)

if(ret["code"] != 0) 
{
 print(ret["message"])		
} else {
 print(paste("Dataset publishing succeeded. Your dataset url is ", base_uri, "/dataset/view/", ret["message"], sep=""))
}

return (ret)
}
